mkdir folder1
ls ~
echo "hi"
cd folder1
echo "I am going to pass the result"
cd ~
cat folder1/f1